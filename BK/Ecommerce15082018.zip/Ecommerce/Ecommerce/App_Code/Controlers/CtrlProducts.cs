﻿using System.Collections.Generic;
using System.ComponentModel;
using DAO;
using Entities;

/// <summary>
/// Summary description for CtrlProducts
/// </summary>
[DataObject]
public class CtrlProducts
{
    [DataObjectMethod(DataObjectMethodType.Select, false)]
    public List<Product> GetAllProducts()
    {
        List<Product> products = new List<Product>();
        ProductsDAO dao = new ProductsDAO();
        products = dao.GetAllProducts();
        return products;
    }

    public void InsertProduct(string name, string description, int categoryId)
    {
        ProductsDAO dao = new ProductsDAO();
        Product newProduct = new Product();
        newProduct.name = name;
        //newProduct.description = description;
        //newProduct.categoryId = categoryId;
        dao.CreateProduct(newProduct);
    }

    public void UpdateProduct(string name, string description, int categoryId, int id)
    {
        ProductsDAO dao = new ProductsDAO();
        Product updatedProduct = dao.GetProduct(id);
        if (updatedProduct != null)
        {
            updatedProduct.name = name;
            //updatedProduct.description = description;
            //updatedProduct.categoryId = categoryId;
            dao.UpdateProduct(updatedProduct);
        }
    }
}